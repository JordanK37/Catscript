package edu.montana.csci.csci468;

import org.junit.jupiter.api.Test;

import static edu.montana.csci.csci468.tokenizer.TokenType.*;
import static org.junit.jupiter.api.Assertions.*;

public class PartnersTest extends CatscriptTestBase {

    @Test
    public void advancedTokenizer(){
        assertTokensAre("100,154", INTEGER, COMMA, INTEGER, EOF);
        assertTokensAre("57 asdf", INTEGER, IDENTIFIER, EOF);
        assertTokensAre("1 \"asdf\" 234234", INTEGER, STRING, INTEGER, EOF);
    }

    @Test
    void advancedExpressionEvaluatesProperly() {
        assertEquals(5, evaluateExpression("1 * 2 + 3"));
        assertEquals(10, evaluateExpression("8 + 4 / 2"));
        assertEquals(7, evaluateExpression("2 * 4 - 2 / 2"));
    }

    @Test
    void advancedComparisonExpressionEvaluatesProperly() {
        assertEquals(false, evaluateExpression("1 - 1 > 2"));
        assertEquals(false, evaluateExpression("1 * 1 >= 2"));
        assertEquals(true, evaluateExpression("1 / 5 <= 2"));
        assertEquals(true, evaluateExpression("1 + -5 < 2"));
    }

}
